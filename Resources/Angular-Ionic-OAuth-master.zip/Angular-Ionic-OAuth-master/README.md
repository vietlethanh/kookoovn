# Angular-Ionic-OAuth
Facebook and Google OAuth with AngularJS and IONIC

DEMO URL: http://techiedreams.com/demos/oauth-ionic-angular/
