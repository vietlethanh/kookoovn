Contact API pickContact Example
===

This example demonstrates the new pickContact support for the Contacts
API. Please run the following line to add the plugin:

    cordova plugin add org.apache.cordova.contacts

This example demonstrates the new API by firing off a call to pickContact
and then displaying the selected result.