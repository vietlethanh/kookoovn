Async Download Example
===

This one is rather complex. I'm going to leave the explanation to the blog post
found here: http://www.raymondcamden.com/2014/11/7/Cordova-and-Asset-Downloads

Please add the following plugins:

	org.apache.cordova.file
	org.apache.cordova.dialogs
	org.apache.cordova.file-transfer
	org.apache.cordova.statusbar
	
