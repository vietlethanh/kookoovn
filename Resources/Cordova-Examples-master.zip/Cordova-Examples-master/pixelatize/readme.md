Pixelatize Demo
===

A simple demo that mashes up the device camera and @jennschiffer's Pixelatize code (https://github.com/jennschiffer/pixelatize). It requires the Camera plugin (cordova-plugin-camera) to work correctly.