Camera VintageJS
===

A Camera demo that makes use of [VintageJS](https://github.com/rendro/vintageJS).


    cordova plugin add org.apache.cordova.camera
