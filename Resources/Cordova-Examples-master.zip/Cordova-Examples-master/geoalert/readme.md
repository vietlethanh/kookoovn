GeoAlert Example
===

A demo that shows alerting a user when they get close to a target. Use these plugins:

    cordova plugin add cordova-plugin-geolocation
	cordova plugin add cordova-plugin-dialogs
	
