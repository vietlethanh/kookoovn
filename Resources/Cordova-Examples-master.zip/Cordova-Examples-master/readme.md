Cordova Demos
===

This repository contains a set of Cordova (PhoneGap) example apps. Each folder contains the www folder for a project. To use it, you may either copy the files manually into a www folder, or use the --copy-from option of the Cordova CLI.

Each folder has its own readme with individual instructions for the project.
