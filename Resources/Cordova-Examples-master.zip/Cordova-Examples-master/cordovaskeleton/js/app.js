document.addEventListener("deviceready", init, false);
function init() {
	
}