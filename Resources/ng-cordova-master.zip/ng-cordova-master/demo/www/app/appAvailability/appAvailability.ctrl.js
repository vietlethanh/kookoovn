angular.module('demo.appAvailability.ctrl', [])

  .controller('AppAvailabilityCtrl', function ($scope, $log, $cordovaPreferences) {

  });
