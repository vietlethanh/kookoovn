ngCordova Demo App
=====================

This is a demo app for ngCordova to show how to use each plugin. Still a WIP

## Using this app:

Start off by adding a cordova platform:

```
cordova platform add ios / android
```

